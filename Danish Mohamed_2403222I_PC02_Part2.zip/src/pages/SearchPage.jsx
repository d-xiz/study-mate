
import TutorCard from "../components/TutorCard";
import StudyGroupCard from "../components/StudyGroupCard";
import { api } from "../api";
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { userApi } from "../api/user";
import Modal from "../components/Modal";


const SearchPage = () => {
 

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const initialTab = searchParams.get("tab");
  const q = searchParams.get("q") || "";

  const [mode, setMode] = useState(initialTab === "group" ? "group" : "tutor");
  const [query, setQuery] = useState(q);
  const [appliedQuery, setAppliedQuery] = useState(q);

  const [tutors, setTutors] = useState([]);
  const [groups, setGroups] = useState([]);
const [currentUser, setCurrentUser] = useState(null);
const [editingGroup, setEditingGroup] = useState(null);

  useEffect(() => {
    if (initialTab === "group" || initialTab === "tutor") {
      setMode(initialTab);
    }
  }, [initialTab]);

   useEffect(() => {
    if (mode === "tutor") {
      api.tutors.searchByModule(appliedQuery).then(setTutors);
    } else {
      api.groups.searchByName(appliedQuery).then(setGroups);
    }
  }, [appliedQuery, mode]);


useEffect(() => {
  userApi.getProfile().then(setCurrentUser);
}, []);
if (!currentUser) {
  return <p>Loading user…</p>;
}



const handleDeleteGroup = (groupId) => {
  // mock delete for now
  setGroups((prev) => prev.filter((g) => g.id !== groupId));
};

  return (
   <main>

  
  <section className="search-toolbar">
    <div className="container search-toolbar-inner">
 <div className="search-center">
      <div className="search-input-group">
        <input
          placeholder="Search module (e.g. LOMA)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button
          className="search-btn"
          onClick={() => setAppliedQuery(query.trim())}
        >
          Search
        </button>
      </div>
      </div>
 </div>
 <div className="container search-toolbar-cta">
      <button
        className="toolbar-cta"
        onClick={() =>
          navigate(mode === "tutor" ? "/become-tutor" : "/create-group")
        }
      >
        {mode === "tutor" ? "Become Tutor" : "Add Study Group"}
      </button>

   </div>
  </section>


  <section className="search-tabs-bar">
    <div className="container">
      <p className="results-meta">
        Search results for: <strong>{appliedQuery || "All"}</strong>
      </p>

      <div className="tabs">
        <button
          className={mode === "tutor" ? "tab active" : "tab"}
          onClick={() => setMode("tutor")}
        >
          Tutors
        </button>
        <button
          className={mode === "group" ? "tab active" : "tab"}
          onClick={() => setMode("group")}
        >
          Study Group
        </button>
      </div>
    </div>
  </section>

  <section className="section">
    <div className="container">
      {mode === "tutor" && (
        <div className="tutor-grid">
          {tutors.map((t) => (
            <TutorCard key={t.id} tutor={t} />
          ))}
        </div>
      )}

      {mode === "group" && (
        <div className="group-list">
          {groups.map((g) => (
            <StudyGroupCard
  key={g.id}
  group={g}
  currentUserId={currentUser.id}
  onEdit={setEditingGroup}
  onDelete={handleDeleteGroup}
/>

          ))}
        </div>
      )}
    </div>
  </section>
{editingGroup && (
  <Modal onClose={() => setEditingGroup(null)}>
    <p style={{ fontWeight: "600", marginBottom: "12px" }}>
      Edit Group: {editingGroup.name}
    </p>

    {/* For MVP, just log update */}
    <button
      onClick={() => {
        console.log("Updated group:", editingGroup);
        setEditingGroup(null);
      }}
    >
      Save Changes
    </button>
  </Modal>
)}

</main>

  );
};

export default SearchPage;
