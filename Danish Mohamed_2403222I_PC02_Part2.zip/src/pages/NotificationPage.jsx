import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { api } from "../api";

 
const NotificationsPage = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    api.notifications.getAll().then(setNotifications);
  }, []);

  return (
    <main className="container">
      <h1>Notifications</h1>

      <div className="notification-list">
        {notifications.map((n) => (
          <div key={n.id} className={`notification-card ${n.status}`}>
            <div className="notification-content">
              <p className="notification-message">{n.message}</p>
              <span className="notification-time">{n.time}</span>
            </div>

           {n.status === "approved" && n.type === "group" && (
  <button
    className="notif-action"
    onClick={() => navigate(`/search?tab=group`)}
  >
    View Group
  </button>
)}

{n.status === "new" && n.type === "tutor" && (
  <button
    className="notif-action"
    onClick={() => navigate(`/search?tab=tutor`)}
  >
    View Tutor
  </button>
)}

          </div>
        ))}
      </div>
    </main>
  );
};

export default NotificationsPage;
