import { useState } from "react";

const CreateGroupPage = () => {
  const [form, setForm] = useState({
    name: "",
    days: [],
    startTime: "",
    endTime: "",
    location: "",
    pax: "",
    description: "",
    resources: [],
  });

  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState("");

  const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const toggleDay = (day) => {
    setForm((prev) => ({
      ...prev,
      days: prev.days.includes(day)
        ? prev.days.filter((d) => d !== day)
        : [...prev.days, day],
    }));
  };

  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    setForm({ ...form, resources: files });
  };

  const validate = () => {
    const err = {};

    if (!form.name.trim()) err.name = "Group name is required";
    if (form.days.length === 0) err.days = "Select at least one day";
    if (!form.startTime || !form.endTime)
      err.time = "Start and end time required";
    if (form.startTime >= form.endTime)
      err.time = "End time must be later than start time";
    if (!form.location.trim()) err.location = "Location required";
    if (!form.pax || Number(form.pax) < 2)
      err.pax = "Minimum 2 participants";

    setErrors(err);
    return Object.keys(err).length === 0;
  };
  const isFormValid =
  form.name &&
  form.days.length > 0 &&
  form.startTime &&
  form.endTime &&
  form.location &&
  Number(form.pax) >= 2;


  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage("");

    if (!validate()) return;

    const payload = {
  ...form,
  admin: "Current User",
};


    console.log("Created group:", payload);
    setMessage("Study group created successfully!");

    // reset
    setForm({
      name: "",
      days: [],
      startTime: "",
      endTime: "",
      location: "",
      pax: "",
      description: "",
      resources: [],
    });
  };

  return (
    <main className="container">
      <h1>Create Study Group</h1>
<form className="group-form" onSubmit={handleSubmit} noValidate>

  {/* BASIC INFO */}
  <fieldset>
    <legend>Basic Information</legend>

    <div className="form-field">
      <label>Group Name</label>
      <input
        name="name"
        value={form.name}
        onChange={handleChange}
      />
      {errors.name && <span className="error">{errors.name}</span>}
    </div>

    <div className="form-field">
      <label>Description (optional)</label>
      <textarea
        rows="3"
        name="description"
        value={form.description}
        onChange={handleChange}
      />
    </div>
  </fieldset>

  {/* SCHEDULE */}
  <fieldset>
    <legend>When & Where</legend>

    <div className="form-field">
      <label>Days</label>
      <div className="checkbox-row">
        {daysOfWeek.map((day) => (
          <label key={day}>
            <input
              type="checkbox"
              checked={form.days.includes(day)}
              onChange={() => toggleDay(day)}
            />
            {day}
          </label>
        ))}
      </div>
      {errors.days && <span className="error">{errors.days}</span>}
    </div>

    <div className="form-row">
      <div className="form-field">
        <label>Start Time</label>
        <input
          type="time"
          name="startTime"
          value={form.startTime}
          onChange={handleChange}
        />
      </div>

      <div className="form-field">
        <label>End Time</label>
        <input
          type="time"
          name="endTime"
          value={form.endTime}
          onChange={handleChange}
        />
      </div>
    </div>

    {errors.time && <span className="error">{errors.time}</span>}
 


 
    

    <div className="form-field">
      <label>Location</label>
      <input
        name="location"
        value={form.location}
        onChange={handleChange}
      />
      {errors.location && <span className="error">{errors.location}</span>}
    </div>

    <div className="form-field">
      <label>Total Pax</label>
      <input
        type="number"
        min="2"
        name="pax"
        value={form.pax}
        onChange={handleChange}
      />
      {errors.pax && <span className="error">{errors.pax}</span>}
    </div>
  </fieldset>

  {/* RESOURCES */}
  <fieldset>
    <legend>Resources</legend>

    <div className="form-field">
      <label>Upload Files</label>
      <input type="file" multiple onChange={handleFiles} />
      {form.resources.length > 0 && (
        <ul className="file-list">
          {form.resources.map((f, i) => (
            <li key={i}>{f.name}</li>
          ))}
        </ul>
      )}
    </div>


  </fieldset>

  <button type="submit" disabled={!isFormValid}>Create Group</button>
</form>


      {message && <p className="success">{message}</p>}
    </main>
  );
};

export default CreateGroupPage;
