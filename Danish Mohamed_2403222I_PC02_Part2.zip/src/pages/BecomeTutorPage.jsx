import { useState } from "react";

const BecomeTutorPage = () => {
  const [form, setForm] = useState({
    name: "",
    qualification: "",
    days: [],
    startTime: "",
    endTime: "",
    modules: [],
    moduleInput: "",
  });

  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState("");

  const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const toggleDay = (day) => {
    setForm((prev) => ({
      ...prev,
      days: prev.days.includes(day)
        ? prev.days.filter((d) => d !== day)
        : [...prev.days, day],
    }));
  };

  const addModule = () => {
    const m = form.moduleInput.trim().toUpperCase();
    if (!m || form.modules.includes(m)) return;

    setForm((prev) => ({
      ...prev,
      modules: [...prev.modules, m],
      moduleInput: "",
    }));
  };

  const removeModule = (m) => {
    setForm((prev) => ({
      ...prev,
      modules: prev.modules.filter((x) => x !== m),
    }));
  };

  const validate = () => {
    const err = {};

    if (!form.name.trim()) err.name = "Name is required";
    if (!form.qualification.trim())
      err.qualification = "Qualification is required";
    if (form.days.length === 0)
      err.days = "Select at least one day";
    if (!form.startTime || !form.endTime)
      err.time = "Start and end time required";
    if (form.startTime >= form.endTime)
      err.time = "End time must be later than start time";
    if (form.modules.length === 0)
      err.modules = "Add at least one module";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const isFormValid =
    form.name &&
    form.qualification &&
    form.days.length > 0 &&
    form.startTime &&
    form.endTime &&
    form.modules.length > 0;

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage("");

    if (!validate()) return;

    const payload = {
      id: Date.now(),
      name: form.name,
      qualification: form.qualification,
      availability: {
        days: form.days,
        startTime: form.startTime,
        endTime: form.endTime,
      },
      modules: form.modules,
    };

    console.log("Tutor registered:", payload);
    setMessage("Tutor profile created successfully!");

    setForm({
      name: "",
      qualification: "",
      days: [],
      startTime: "",
      endTime: "",
      modules: [],
      moduleInput: "",
    });
  };

  return (
    <main className="container">
      <h1>Become a Tutor</h1>

      <form className="group-form" onSubmit={handleSubmit} noValidate>

        {/* BASIC INFO */}
        <fieldset>
          <legend>Basic Information</legend>

          <div className="form-field">
            <label>Name</label>
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
            />
            {errors.name && <span className="error">{errors.name}</span>}
          </div>

          <div className="form-field">
            <label>Qualification</label>
            <input
              name="qualification"
              value={form.qualification}
              onChange={handleChange}
            />
            {errors.qualification && (
              <span className="error">{errors.qualification}</span>
            )}
          </div>
        </fieldset>

        {/* AVAILABILITY */}
        <fieldset>
          <legend>Availability</legend>

          <div className="form-field">
            <label>Days</label>
            <div className="checkbox-row">
              {daysOfWeek.map((day) => (
                <label key={day}>
                  <input
                    type="checkbox"
                    checked={form.days.includes(day)}
                    onChange={() => toggleDay(day)}
                  />
                  {day}
                </label>
              ))}
            </div>
            {errors.days && <span className="error">{errors.days}</span>}
          </div>

          <div className="form-row">
            <div className="form-field">
              <label>Start Time</label>
              <input
                type="time"
                name="startTime"
                value={form.startTime}
                onChange={handleChange}
              />
            </div>

            <div className="form-field">
              <label>End Time</label>
              <input
                type="time"
                name="endTime"
                value={form.endTime}
                onChange={handleChange}
              />
            </div>
          </div>

          {errors.time && <span className="error">{errors.time}</span>}
        </fieldset>

        {/* MODULES */}
        <fieldset>
          <legend>Modules</legend>

          <div className="form-row">
            <div className="form-field">
              <label>Add Module</label>
              <input
                value={form.moduleInput}
                onChange={(e) =>
                  setForm({ ...form, moduleInput: e.target.value })
                }
              />
            </div>
            <button type="button" onClick={addModule}>
              Add
            </button>
          </div>

          {form.modules.length > 0 && (
            <ul className="file-list">
              {form.modules.map((m) => (
                <li key={m}>
                  {m}{" "}
                  <button type="button" onClick={() => removeModule(m)}>
                    ✕
                  </button>
                </li>
              ))}
            </ul>
          )}

          {errors.modules && (
            <span className="error">{errors.modules}</span>
          )}
        </fieldset>

        <button type="submit" disabled={!isFormValid}>
          Create Tutor Profile
        </button>
      </form>

      {message && <p className="success">{message}</p>}
    </main>
  );
};

export default BecomeTutorPage;
