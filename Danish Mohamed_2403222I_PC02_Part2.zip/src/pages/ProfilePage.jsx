
import { useEffect, useState } from "react";
import { api } from "../api";

const ProfilePage = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    api.user.getProfile().then(setUser);
  }, []);

  if (!user) {
    return null}

  return (
    <main className="profile-page">

      {/* HEADER */}
      <div className="profile-header">
        <div className="profile-info">
        <img
  src={user.avatar}
  alt={`${user.name} profile`}
  className="avatar-lg"
/>

        <div>
          <h1>{user.name}</h1>
          <p className="profile-role">{user.role}</p>
        </div>
        </div>
       
      </div>

      {/* STATS BAR */}
      <div className="profile-stats-bar">
        <div className="stat">
          <strong>{user.stats.created}</strong>
          <span>Groups Created</span>
        </div>
        <div className="stat">
          <strong>{user.stats.joined}</strong>
          <span>Groups Joined</span>
        </div>
        <div className="stat">
          <strong>{user.stats.tutored}</strong>
          <span>Tutor Sessions</span>
        </div>
      </div>

      <div className="profile-body">

        {/* LEFT – ABOUT */}
        <aside className="profile-left">
          <section>
            <h4>About</h4>
            <p><strong>Course:</strong> {user.course}</p>
          </section>

          <section>
            <h4>Strong Modules</h4>
            <div className="tag-row">
              {user.strong.map(m => (
                <span key={m} className="tag">{m}</span>
              ))}
            </div>
          </section>

          <section>
            <h4>Needs Help In</h4>
            <div className="tag-row">
              {user.help.map(m => (
                <span key={m} className="tag muted">{m}</span>
              ))}
            </div>
          </section>
        </aside>

        {/* RIGHT – ACTIVITY */}
        <section className="profile-right">

          <h3>Currently Active</h3>
          <div className="activity-card active">
            <strong>{user.activeGroup.name}</strong>
            <span>{user.activeGroup.detail}</span>
          </div>

          <h4 className="section-sub">Past Groups</h4>
          {user.pastGroups.map((g, i) => (
            <div key={i} className="activity-item">
              <strong>{g.name}</strong>
              <span>{g.detail}</span>
            </div>
          ))}

          <h4 className="section-sub">Tutor Sessions</h4>
          <p className="empty-state">No active tutoring sessions.</p>

        </section>

      </div>
    </main>
  );
};

export default ProfilePage;
