import { useState, useEffect } from "react";
import Modal from "./Modal";
const StudyGroupCard = ({ group ,currentUserId ,onEdit, onDelete}) => {
    const [open, setOpen] = useState(false);
const [message, setMessage] = useState("");
const [success, setSuccess] = useState(false);
const isOwner = group.adminId === currentUserId;



const openModal = () => {
  setMessage("");
  setSuccess(false);
  setOpen(true);
};
useEffect(() => {
  if (success) {
    const timer = setTimeout(() => {
      setOpen(false);
    }, 1000); //After 1 seconds the modal will close
    return () => clearTimeout(timer);
  }
}, [success]); 
  const formatTime = (time) => {
    const [h, m] = time.split(":");
    const hour = Number(h);
    const suffix = hour >= 12 ? "PM" : "AM";
    const displayHour = hour % 12 || 12;
    return `${displayHour}${m !== "00" ? `:${m}` : ""}${suffix}`;
  };

  const scheduleText =
    group.days.length === 1
      ? `Every ${group.days[0]} • ${formatTime(group.startTime)}–${formatTime(group.endTime)}`
      : `${group.days.join(" & ")} • ${formatTime(group.startTime)}–${formatTime(group.endTime)}`;

  return (
    <>
    <div className="group-row">

      <div className="group-main">
        <h4 className="group-title">{group.name}</h4>

        <div className="group-meta">
          <p>
             <span>{isOwner ? "You" : "Admin"}</span> {group.admin}
          </p>
          <p>{scheduleText}</p>
        </div>

        <div className="group-footer">
          <p className="location">{group.location}</p>
          <p className="pax">
            <span>Total pax</span> {group.pax}
          </p>
        </div>
      </div>

     

      <div className="group-action">
  {isOwner ? (
    <>
      <button
        className="view-btn"
        onClick={() => onEdit(group)}
      >
        Edit
      </button>

      <button
        className="request-btn"
        onClick={() => {
          if (!onDelete) return;

          if (!window.confirm("Delete this group?")) return;
          onDelete(group.id);
        }}
      >
        Delete
      </button>
    </>
  ) : (
    <button className="join-btn" onClick={openModal}>
      Join
    </button>
  )}
</div>

       </div>
{!isOwner && (
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={`Join ${group.name}`}
      >
        <p><strong>Schedule:</strong> {scheduleText}</p>
        <p><strong>Location:</strong> {group.location}</p>
        {success && (
  <p style={{ color: "green", fontWeight: "600" }}>
     Request sent successfully!
  </p>
)}


         <textarea
         className="modal-msg"
          placeholder="Message to admin (optional)"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
<div className="modal-action">
        <button className="modal-btn" disabled={success} onClick={() => {
            console.log({
              group: group.name,
              message,
            });
            setSuccess(true);
          }}>
          Join Group
        </button>
        </div>
      </Modal>
      )}
    </>

  );
};

export default StudyGroupCard;
