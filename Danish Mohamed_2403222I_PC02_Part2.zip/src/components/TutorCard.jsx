import { useState, useEffect } from "react";
import Modal from "./Modal";
 const formatTime = (time) => {
  const [h, m] = time.split(":");
  const hour = Number(h);
  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${displayHour}${m !== "00" ? `:${m}` : ""}${suffix}`;
};

const formatAvailability = ({ days, startTime, endTime }) => {
  const time = `${formatTime(startTime)}–${formatTime(endTime)}`;

  if (days.length === 1) {
    return `Every ${days[0]} • ${time}`;
  }

  return `${days.join(", ")} • ${time}`;
};


const TutorCard = ({ tutor }) => {
  const [open, setOpen] = useState(false);
  const [selectedModule, setSelectedModule] = useState("");
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [openProfile, setOpenProfile] = useState(false);


  const openModal = () => {
  if (!tutor.modules || tutor.modules.length === 0) return;
  setSelectedModule(tutor.modules[0]);
  setMessage("");
  setSuccess(false);
  setOpen(true);
};
useEffect(() => {
  if (success) {
    const timer = setTimeout(() => {
      setOpen(false);
    }, 1000); //After 1 seconds the modal will close

    return () => clearTimeout(timer);
  }
}, [success]);

  
  const availabilityText = formatAvailability(tutor.availability);
  return (
    <>
    <div className="card tutor-card">
      
      <div className="card-top">
        <img
        src={tutor.avatar}
        alt={`${tutor.name} profile`}
        className="avatar"
      />


        <div className="card-info">
          <h3>{tutor.name}</h3>
          <p className="qualification">{tutor.qualification}</p>
          <p className="availability">{availabilityText}</p>

          <p className="expert">Expert in:</p>
{tutor.modules?.length > 0 && (
          <div className="tags">
            {tutor.modules.map((m) => (
              <span key={m} className="tag">
                {m}
              </span>
            ))}
          </div>
          )}
        </div>
      </div>
      <div className="card-actions">
<button
 className="view-btn"
  
  onClick={() => setOpenProfile(true)}
>
  View Profile
</button>
     <button className="request-btn" onClick={openModal}>
  Request
</button>
          </div>

        </div>
       <Modal
  open={openProfile}
  onClose={() => setOpenProfile(false)}
  title={tutor.name}
>
  {/* Qualification */}
  <p className="profile-role">{tutor.qualification}</p>

  {/* Modules */}
  <h4>Modules Taught</h4>
  <div className="tag-row">
    {tutor.modules.map((m) => (
      <span key={m} className="tag">{m}</span>
    ))}
  </div>

  {/* Availability */}
  <h4 style={{ marginTop: "16px" }}>Availability</h4>
  <p>
    {tutor.availability.days.join(", ")} •{" "}
    {formatTime(tutor.availability.startTime)} –{" "}
    {formatTime(tutor.availability.endTime)}
  </p>

  {/* CTA */}
  <div className="modal-action">
    <button
      className="modal-btn"
      onClick={() => {
        setOpenProfile(false);
        setOpen(true);
      }}
    >
      Request Session
    </button>
  </div>
</Modal>

      
      <Modal
      open={open}
        onClose={() => setOpen(false)}
        title={`Request session with ${tutor.name}`}
      >
        <p >Select module: </p>
        <select
        className=" module-select"
  value={selectedModule}
  onChange={(e) => setSelectedModule(e.target.value)}
>
          {tutor.modules.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </select>
{success && (
  <p style={{ color: "green", fontWeight: "600" }}>
     Request sent successfully!
  </p>
)}

       <textarea
  className="modal-msg"
  placeholder="Message to tutor (optional)"
  value={message}
  onChange={(e) => setMessage(e.target.value)}
/>
<div className="modal-action">

        <button className="modal-btn" disabled={success} onClick={() => {
    console.log({
      tutor: tutor.name,
      module: selectedModule,
      message,
    });
    setSuccess(true);
   
  }}>
          Send Request
        </button>
        </div>
      </Modal>
      </>
          
  );
};

export default TutorCard;
