const subjects = [
  {
    code: "FWEB",
    tutors: 6,
    groups: 3,
  },
  {
    code: "DBMS",
    tutors: 5,
    groups: 4,
  },
  {
    code: "LOMA",
    tutors: 8,
    groups: 5,
  },
  {
    code: "CFUN",
    tutors: 4,
    groups: 2,
  },
  {
    code: "ADAV",
    tutors: 3,
    groups: 2,
  },
  {
    code: "ITAD",
    tutors: 5,
    groups: 3,
  },
];

export default subjects;
