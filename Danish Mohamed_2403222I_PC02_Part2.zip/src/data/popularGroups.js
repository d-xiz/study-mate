const popularGroups = [
  {
    id: 1,
    name: "LOMA Exam Prep",
    admin: "Ryan",
    location: "Tampines Library",
  },
  {
    id: 2,
    name: "FWEB React Study Group",
    admin: "Aisha",
    location: "Online (Zoom)",
  },
  {
    id: 3,
    name: "DBMS SQL Practice",
    admin: "Kevin",
    location: "NYP Block L",
  },
  {
    id: 4,
    name: "CFUN Python Basics",
    admin: "Siti",
    location: "Jurong East Library",
  },
  {
    id: 5,
    name: "ADAV Assignment Help",
    admin: "Daniel",
    location: "Online (Discord)",
  },
];

export default popularGroups;
