const tutors = [
  {
    id: 1,
    name: "Ryan",
    avatar: "/avatars/pic2.png",
    qualification: "Diploma in IT (Year 2)",
    availability: {
      days: ["Mon", "Tue", "Wed"],
      startTime: "17:00",
      endTime: "19:00",
    },
    modules: ["LOMA", "FWEB"],
  },
  {
    id: 2,
    name: "Aisha",
    avatar: "/avatars/pic3.png",
    qualification: "Diploma in IT (Year 3)",
    availability: {
      days: ["Thu", "Fri"],
      startTime: "18:00",
      endTime: "20:00",
    },
    modules: ["DBMS", "CFUN"],
  },
  {
    id: 3,
    name: "Kevin",
    avatar: "/avatars/pic4.png",
    qualification: "Diploma in Data Science (Year 2)",
    availability: {
      days: ["Sat"],
      startTime: "10:00",
      endTime: "13:00",
    },
    modules: ["DBMS", "ITAD"],
  },
  {
    id: 4,
    name: "Siti",
    avatar: "/avatars/pic5.png",
    qualification: "Diploma in Data Science",
    availability: {
      days: ["Mon", "Thu"],
      startTime: "16:00",
      endTime: "18:00",
    },
    modules: ["CFUN", "ADAV"],
  },
  {
    id: 5,
    name: "Daniel",
    avatar: "/avatars/pic6.png",
    qualification: "Diploma in IT (Graduate)",
    availability: {
      days: ["Wed", "Sun"],
      startTime: "19:00",
      endTime: "21:00",
    },
    modules: ["FWEB", "LOMA"],
  },
];

export default tutors;
