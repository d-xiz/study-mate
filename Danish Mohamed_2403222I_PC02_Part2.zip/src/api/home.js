import subjects from "../data/subjects";
import popularGroups from "../data/popularGroups";

export const homeApi = {
  getSubjects: () => {
   
    return Promise.resolve(subjects);
  },

  getPopularGroups: () => {
    return Promise.resolve(popularGroups);
  }
};
