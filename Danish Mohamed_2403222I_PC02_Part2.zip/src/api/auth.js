export const authApi = {
  login: (admissionNo, password) => {
    if (!admissionNo || !password) {
      return Promise.reject("Invalid credentials");
    }
    return Promise.resolve({ admissionNo, role: "student" });
  },

  signup: (name, admissionNo, password) => {
    if (!name || !admissionNo || !password) {
      return Promise.reject("Invalid input");
    }
    return Promise.resolve();
  },

  logout: () => {
    return Promise.resolve();
  }
};
