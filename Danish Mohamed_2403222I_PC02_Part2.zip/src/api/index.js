import { tutorsApi } from "./tutors";
import { groupsApi } from "./groups";
import { authApi } from "./auth";
import { homeApi } from "./home";
import { notificationsApi } from "./notifications";
import { userApi } from "./user";

export const api = {
  tutors: tutorsApi,
  groups: groupsApi,
  auth: authApi,
  home: homeApi,
  notifications: notificationsApi,
    user: userApi,
};
