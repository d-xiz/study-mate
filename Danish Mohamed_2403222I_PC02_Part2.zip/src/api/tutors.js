import tutorData from "../data/tutors";

export const tutorsApi = {
  getAll: () => {
    return Promise.resolve(tutorData);
  },

  searchByModule: (query) => {
    if (!query) {
      return Promise.resolve(tutorData);
    }

    const result = tutorData.filter((tutor) =>
      tutor.modules.some((m) =>
        m.toLowerCase().includes(query.toLowerCase())
      )
    );

    return Promise.resolve(result);
  }
};
