const mockUser = {
      id: 1001,
    name: "Danish",
    role: "IT Student • Year 2",
    course: "Information Technology",
    avatar: "/avatars/pic1.png",
    strong: ["FWEB", "DBMS"],
    help: ["Math"],
    stats: {
      created: 3,
      joined: 5,
      tutored: 2,
    },
    activeGroup: {
      name: "FWEB Project Group",
      detail: "Admin • Tue & Thu • 5–7 PM",
    },
    pastGroups: [
      {
        name: "DBMS Revision Group",
        detail: "Joined • Sat • 2–4 PM",
      },
    ],
  };
  export const userApi = {
  getProfile: () => Promise.resolve(mockUser),
};