const notifications = [
  {
    id: 1,
    type: "group",
    status: "approved",
    message: "Your request to join FWEB Project Group was approved.",
    time: "2 hours ago",
    targetId: 7,
  },
  {
    id: 2,
    type: "group",
    status: "rejected",
    message: "Your request to join DBMS Study Group was rejected.",
    time: "1 day ago",
  },
  {
    id: 3,
    type: "tutor",
    status: "new",
    message: "New tutor available for DBMS.",
    time: "Just now",
    targetId: 2,
  },
];
export const notificationsApi = {
  getAll: () => Promise.resolve(notifications),
};