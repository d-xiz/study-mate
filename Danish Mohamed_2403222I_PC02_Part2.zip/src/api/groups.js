import initialGroupData from "../data/studyGroups";

let groups = [...initialGroupData];

export const groupsApi = {
  getAll: () => {
    return Promise.resolve(groups);
  },

  searchByName: (query) => {
    if (!query) {
      return Promise.resolve(groups);
    }

    const result = groups.filter((group) =>
      group.name.toLowerCase().includes(query.toLowerCase())
    );

    return Promise.resolve(result);
  },

  create: (data) => {
    const newGroup = {
      ...data,
      id: `group_${Date.now()}`, // simple unique id
    };

    groups.push(newGroup);
    return Promise.resolve(newGroup);
  },

  update: (id, updatedData) => {
    groups = groups.map((group) =>
      group.id === id ? { ...group, ...updatedData } : group
    );

    return Promise.resolve();
  },

  delete: (id) => {
    groups = groups.filter((group) => group.id !== id);
    return Promise.resolve();
  },
};

export default groupsApi;